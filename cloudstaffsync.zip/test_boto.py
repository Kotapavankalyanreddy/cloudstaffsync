import boto3
print(boto3.__version__)
